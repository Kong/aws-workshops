---
title : "Delete ME - Authoring the workshop"
weight : 10
---

# INTRODUCTION

We will eventually delete this section, but for now keep it here so that you can refer this guide when required.