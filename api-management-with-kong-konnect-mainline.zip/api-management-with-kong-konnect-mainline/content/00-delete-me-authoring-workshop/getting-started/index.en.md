---
title : "Getting Started"
weight : 11
---

# What's included

This project the following folders:

* static: Store any static assets to be hosted alongside the workshop (ie. images, scripts, documents, etc).
* content: This is the core workshop folder.
