---
title: 'Local Development'
weight: 99
---

### What is the local development preview utility?

The local development preview utility allows you to view changes to your content without having to push changes to the repository. You run the utility on your computer to perform local builds. When you update content, the webpages will automatically reload so you can view your changes. This makes content authoring and editing easier and faster.

### Downloading the local development preview utility

Refer the email sent

