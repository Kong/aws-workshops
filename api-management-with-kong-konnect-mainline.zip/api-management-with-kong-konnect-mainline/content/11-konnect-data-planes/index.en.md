---
title : "Konnect Data Plane"
weight : 11
---

* Each Section should include a small introduction and learning objectives

* Data plane setup with EKS (Section)
* Data plane setup with ECS (Section), not required for MVP. Should be independelty executable
