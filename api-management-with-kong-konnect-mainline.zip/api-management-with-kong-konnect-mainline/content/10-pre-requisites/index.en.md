---
title : "Pre-Requisites"
weight : 10
---

* Each Section should include a small introduction and learning objectives

* Sectional contents similar to https://github.com/aws-samples/aws-modernization-with-kong/tree/master/content/pre-requsites

* Use AWS Command Shell instead of Cloud9 in instructions

* Replace https://github.com/aws-samples/aws-modernization-with-kong/tree/master/content/pre-requsites/kong-enterprise-license with Konnect sign up (dont include data plane setup)