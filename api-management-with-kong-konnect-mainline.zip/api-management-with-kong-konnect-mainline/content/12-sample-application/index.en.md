---
title : "Sample Application"
weight : 12
---
* Each Section should include a small introduction and learning objectives
* Sample App setup (External, DNS based)
* Sample App on Lambda