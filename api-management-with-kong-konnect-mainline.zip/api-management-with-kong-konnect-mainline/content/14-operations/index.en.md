---
title : "Operations"
weight : 14
---

* Each Section should include a small introduction and learning objectives

* Telemetery
* GitOps/ApiOps (Pull based setup, if possible with Konnect)