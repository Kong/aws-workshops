---
title: "API Management with Kong Konnect"
weight: 0
---

# API Management with Kong Konnect

This section (single page only), no subsections required should include

* Introduction to Kong Konnect
* Learning Objectives (Bullets)
* Expected Duration
* Approx cost