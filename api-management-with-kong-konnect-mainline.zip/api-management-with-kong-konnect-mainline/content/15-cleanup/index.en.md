---
title : "Cleanup"
weight : 15
---

* Each Section should include a small introduction and learning objectives

* Cleanup AWS and Kong Resources