# Workshop Studio Assets

This folder used for storing static assets in a remote S3 bucket and folder dedicated to your workshop. For instructions on how to leverage S3 to store asset files, see the instructions at:

<https://studio.us-east-1.prod.workshops.aws/preview/580d5100-7d5d-4475-a08a-869479cdb428/builds/$LATEST/en-US/authoring-a-workshop/managing-workshop-assets>
